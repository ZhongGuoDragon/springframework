package com.tom.spitter.db;

public interface SpittlesMapper {
    public Spittles getSpittles(long id);
}
